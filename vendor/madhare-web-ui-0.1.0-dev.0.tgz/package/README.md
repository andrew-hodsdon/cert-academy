# @madhare/web-ui 0.1.0-dev.0

Neutral-core controls, Radiant actions, reader styles, icons and asset-origin configuration for Mad Hare Web (release `madhare-radiant-v0.1.0-dev.0`). Built ESM with declarations and compiled CSS; no source-only imports. Private package: see `LICENSE.md`.

## Install

```sh
npm install ./madhare-web-ui-0.1.0-dev.0.tgz react react-dom @headlessui/react @heroicons/react clsx
```

Peer dependencies (explicit, not bundled): `react` and `react-dom` `^19.2.0`, `@headlessui/react` `^2.2.10`, `@heroicons/react` `^2.2.0`, `clsx` `^2.1.1`. Inter (`@fontsource/inter` 5.3.0, SIL OFL) is a regular dependency and served locally; there is no CDN. Tailwind is **not** required: `styles.css` is compiled.

## Use

```tsx
import '@madhare/web-ui/styles.css'   // reset + utilities used by the components + tokens + control classes + reader
import '@madhare/web-ui/fonts.css'    // optional: local Inter
import { Button, Input, Toggle, Dialog, CheckIcon } from '@madhare/web-ui'
```

Scope a theme with `@madhare/web-themes` (`<div data-mh-theme="radiant">`); without it the neutral tokens apply.

## Public exports

| Family (Figma node) | Export | Documented variants / states |
| --- | --- | --- |
| Button 5:159 | `Button` | `size` sm/md/lg, `appearance` solid/outline (`variant` primary/secondary alias), hover/focus (`preview` or real), `disabled`, `icon` + `iconPosition`; 24 variants |
| Input 5:180 | `Input` | default, focus, `error`, `disabled`, label, help text |
| Badge 5:187 | `Badge` | subtle, solid, outline |
| Checkbox 5:201 | `Checkbox` | `false`, `true`, `'mixed'` |
| Toggle 5:206 | `Toggle` | off/on, inline source geometry (44×25 viewBox) or hosted exact SVG via `artwork` |
| NavigationItem 5:213 | `NavigationItem` | default, hover, `current` |
| Tab 5:220 | `TabGroup` `TabList` `Tab` `TabPanels` `TabPanel` | default, hover, current (Headless UI) |
| Card 5:227 | `Card` | outline, raised |
| Alert 5:234 | `Alert` | info, error |
| TableRow 5:245 | `Table` (`appearance="neutral"`), `EditableCell` | header, body, editable cells |
| Stat 5:246 | `Stat` | label, value, caption |
| Icons 5:2 5:5 5:9 5:12 | `CheckIcon` `ArrowRightIcon` `ChevronDownIcon` `MenuIcon` | source path data, `currentColor`, intrinsic sizes |

Also: `Dialog`, `Swatch`, `Meter`, `EmptyState`, `DescriptionList`, `PageHeader`, `Panel`, `StatusBadge`, `Stats`, `StubResultNotice`, `Reader`, Radiant `RadiantButton` `RadiantLink` `LinkProvider` `Gradient` `Heading` `Subheading` `Lead`, and `AssetImage` (shows an unavailable state when its file fails).

## Asset origin

```ts
import { configureAssets, placeholderImage, resolveAsset } from '@madhare/web-ui/assets'
configureAssets({ origin: 'https://images.example.org/madhare' }) // no trailing slash; null = inline placeholders
```

Exact Figma artwork ships in `assets/figma/` (`@madhare/web-ui/figma/toggle-on.svg`); the generated placeholder set is in `dist/placeholders/` (`@madhare/web-ui/placeholders/photo-0.svg`). Publish those folders at the configured origin. No live origin is built in.

## Changes from 0.1.0

Source TypeScript is no longer shipped; the `@madhare/web-ui/next` adapter and the `next` peer are removed (`LinkProvider` accepts any link renderer, e.g. `next/link`); `Button` gains `size`/`appearance`/`icon`; the toggle artwork renders at its intrinsic 44×25 size instead of being stretched into 24px.
