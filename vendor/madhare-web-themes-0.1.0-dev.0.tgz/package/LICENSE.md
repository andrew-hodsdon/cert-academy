Mad Hare Web — private commercial notice

These packages are private Mad Hare company software (release madhare-radiant-v1.0.0, 1.0.0 candidate). They are
marked `private` and must not be published to a public registry or redistributed.

They contain material adapted from commercially licensed Tailwind Plus template kits and UI blocks (Application UI,
Marketing, Ecommerce and the Radiant/Salient and related templates). The vendor licence texts are retained in the
source evidence snapshot (24 snapshots under provenance/). Their terms include no public template-kit redistribution;
possession of the archives does not by itself establish developer-seat entitlement or distribution scope, which remains
for the licence owner to confirm. Do not extract, publish or resell the adapted modules as a template kit.

Third-party components kept under their own licences:
- Inter (SIL OFL 1.1) via @fontsource/inter 5.3.0
- Arimo (SIL OFL 1.1, per the package license field) via @fontsource/arimo 5.3.0
- Noto Serif (SIL OFL 1.1) via @fontsource/noto-serif 5.3.0
- Mona Sans (SIL OFL 1.1), file and OFL.txt in @madhare/web-themes assets/fonts/mona-sans
- Headless UI and Heroicons (MIT), React (MIT), Tailwind CSS (MIT) as peer or build dependencies
- Constellation figures in the Mad Hare preview: adapted from IAU / Sky & Telescope charts; patterns by Alan MacRobert.
  CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Modified from the source charts.
