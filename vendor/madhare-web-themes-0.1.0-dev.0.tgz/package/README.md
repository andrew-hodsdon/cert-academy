# @madhare/web-themes 0.1.0-dev.0

Radiant, Salient and Mad Hare as versioned **configuration records** (release `madhare-radiant-v0.1.0-dev.0`), one generator that turns a record into CSS custom properties, generated theme CSS and local fonts. Themes are data; components and templates are shared.

```tsx
import '@madhare/web-themes/themes.css'          // all three records as [data-mh-theme] scopes
import '@madhare/web-themes/fonts/salient.css'   // Arimo + Noto Serif (local); radiant.css = Inter; madhare.css = Mona Sans
import { themes, themeToCss, themeAttributes } from '@madhare/web-themes'
<div {...themeAttributes('salient')}>…</div>     // put the attribute on a wrapper, not on <html>
```

A record has identity/version, source references, raw palette, semantic role → palette mapping, named surfaces, font faces with licence, typography roles, radii, layout and template list, plus a `gaps` list of anything the supplied design does not define. Semantic roles feed `--mh-*` and the neutral-core `--library-*` tokens, and re-point the `indigo` and `gray` scales used by the block modules to the theme accent and ink.

| Theme | Fonts | Palette |
| --- | --- | --- |
| Radiant | Inter (`@fontsource/inter` 5.3.0, OFL) | #171717, #FFFFFF, #525252, #F5F5F5, #E60076; cream→pink→violet hero |
| Salient (approved report) | Arimo + Noto Serif (both OFL 1.1), `@fontsource` 5.3.0 | ink #123951, green #247256, pale #EEF5EF, text #243B47, muted #60717A, line #DCE3E5, canvas #F2F4F3 |
| Mad Hare | Mona Sans variable woff2 (OFL, file and OFL.txt in `assets/fonts/mona-sans`) | orange #F8A05B, ink #171C1B, text #F3F1E9, muted #C2CAC8, seven dark surfaces |

Peer-free (dependencies are the fontsource packages). JSON copies of the records: `@madhare/web-themes/records/<id>.json`.
